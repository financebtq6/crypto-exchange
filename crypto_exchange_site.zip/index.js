
import React from 'react';
import ReactDOM from 'react-dom';
import CryptoExchange from './App';
ReactDOM.render(<CryptoExchange />, document.getElementById('root'));
